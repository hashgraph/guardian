# VMR0015 v1.0 — Safe Drinking Water dMRV (Hedera Guardian)

Guardian implementation of **Verra VMR0015 v1.0** — *Revision to AMS-III.AV.: Low Greenhouse Gas Emitting Safe Drinking Water Production Systems* (active since 31 Oct 2025; replaces standalone AMS-III.AV.). Built for the DLT Earth Methodology Bounty Program.

## TL;DR — what changed since last review

- The on-chain calculation is now **driven end-to-end**: a Monitoring Report submitted with the **Emission Reductions field left blank** has its value **computed by the policy** and **minted** — no manually entered credit amounts.
- Validated against a **real Verra project, VCS 3599** (Grouped Projects for Safe Drinking Water for Schools in Viet Nam): the policy reproduces **ER = 154,125.14 tCO₂e → 154,125 VCU**, matching the registry issuance.
- Added a **policy integrity test** (runnable, 9/9 pass) and a **VMR0015 v1.0 provision-alignment** document.

## 1. What the policy does

1. Onboards Project Proponent, VVB, and Standard Registry roles.
2. Collects baseline/project monitoring data via the Monitoring Report schema.
3. Runs the AMS-III.AV. equations **on-chain** to derive BE, PE, LE and ER.
4. Enforces the VMR0015 §6.1 **water-quality gate** (>10% appliance failure → ER = 0, fail-closed).
5. Routes the report through **VVB verification → SR approval → token mint**, producing a Verifiable Presentation and Trustchain.

## 2. On-chain equations

```
SEC  = 357.48 / nwb                                                  [AMS-III.AV Eq.5]
BE_y = QPW_y × m × X_boil × SEC × (BL_fuel × f_i × EF_fuel × 1e-9)  [Eq.1]
ER_y = BE_y − PE_y − LE_y                                            [Eq.7]
Water-quality gate: pass_rate < 0.90 → ER_y = 0  (fail-closed)      [§6.1]
```

Parameter → Monitoring Report field mapping:

| Parameter | Field | | Parameter | Field |
|---|---|---|---|---|
| QPW_y | field12 | | f_i (fNRB, TOOL33) | field17 |
| m | field13 | | BL_fuel | field18 |
| X_boil | field14 | | PE_y | field4 |
| nwb | field15 | | LE_y | field5 |
| EF_fuel | field16 | | **BE_y (computed)** | **field3** |
| WQ pass/total | field10/field11 | | **ER_y (computed, mint rule)** | **field6** |

## 3. Verified result — real Verra project (VCS 3599)

Test data is grounded in **VCS 3599**, a registered Verra safe-drinking-water project in Vietnam (linked to the World Bank Emission Reduction-Linked Bond for clean water). Parameters were back-calculated from the project's verified ER spreadsheet so the on-chain equations reproduce the registry figure.

Monitoring period: **01 Jan – 30 Jun 2025**.

```
Inputs: QPW=713,972,729 L | m=0.95 | X_boil=1.0 | nwb=0.10
        EF=81.6 tCO2/TJ | f_i=0.82 | BL_fuel=1.0 | PE=0 | LE=8,116 | WQ=95/100

SEC  = 357.48 / 0.10 = 3,574.8
BE_y = 162,241.14 tCO2e
ER_y = 162,241.14 − 0 − 8,116.00 = 154,125.14 tCO2e  →  154,125 VCU
```

This matches the Verra registry issuance for VCS 3599.

## 4. Live dry-run evidence (the calculation is policy-driven, not entered)

Hedera testnet dry-run, 2026-06-14, policy instance `6a2eb894…`, token `0e34f609…`:

| Stage | Document | Signer (role) | Result |
|---|---|---|---|
| Submit | MR `bf772a1e` | PP | **ER field left blank** → calc injected field3=162241.14, field6=154125.14 |
| Verify | MR `4f777343` | VVB | values preserved |
| Approve | MR (final) | SR | values preserved |
| **Mint** | MintToken `4c4f77e8` | SR | **amount = 154125.14** |
| Trustchain | VP `698899da` | SR | bundles MR + MintToken |

The signed VCs are included under `evidence/`. The minted amount equals the **computed** ER — confirming the methodology equations drive issuance.

A second control run (deliberately tiny inputs, ER computes negative) minted **0.00**, demonstrating the conservative floor and that the value is genuinely computed, not echoed from input.

## 5. Policy integrity test

`tests/policy_integrity_test.js` embeds the **verbatim** `calculate_report_fields` expression from the policy binary and asserts behaviour (run `node policy_integrity_test.js`, exit 0 = pass). **9/9 pass:**

- Canonical VCS 3599 → 162,241.14 / 154,125.14 / 154,125 VCU
- WQ gate: 85% → 0, 90% boundary → credits, no sampling → 0
- nwb=0 → BE 0; PE+LE>BE → ER 0 (no negative credits)
- Typed field3/field6 overwritten by computed values (cannot mint arbitrary amounts)

## 6. VMR0015 v1.0 alignment

See `docs/VMR0015_v1.0_provision_alignment.md` for a provision-by-provision map (leakage adjustment factor set at validation; fNRB via TOOL33; REDD+ double-counting assessment — N/A for a water-purification project; interacting-technologies baseline via X_boil; §6.1 gate).


## 6b. VMR0015 v1.0 REDD+ double-counting (NEW)

The Monitoring Report schema now captures the v1.0 REDD+ requirement:
- `field19` (Boolean, required) — "REDD+ double-counting assessed (no overlap with REDD+/jurisdictional REDD+)"
- `field20` (Text) — justification/reference

In the 2026-06-15 canonical dry-run, `field19 = true` and `field20` = "Point-of-use water
purification; no REDD+ or jurisdictional REDD+ overlap" were captured on the signed Monitoring Report
and preserved through VVB verification, SR approval, and into the Verifiable Presentation — without
affecting the computed ER (still 154,125.14). This closes the one VMR0015 v1.0 provision the earlier
submission did not implement.

## 7. Repository contents

```
Emission Reductions from Safe Drinking Water Supply/
├── policy/        VMR0015 ...1781446804289.policy  (the validated instance)
├── schemas/       16 schemas (xlsx export included)
├── formulas/      formula.json, VMR0015_formula.zip
├── tests/         policy_integrity_test.js  (+ canonical fixture, dry-run record)
├── docs/          VMR0015_v1.0_provision_alignment.md
├── evidence/      signed VCs: PUBLISH, MR (submit/verify/approve), MintToken, VP
└── workflow.png   PP → VVB → SR → mint lifecycle
```

## 8. How to review

1. **Math:** open `formulas/formula.json`, cross-check `calculate_report_fields`.
2. **Reproduce:** `node tests/policy_integrity_test.js` → 9/9 pass, canonical = 154,125.
3. **On-chain:** inspect `evidence/` — MR (field6 computed) → MintToken (154125.14) → VP.
4. **Alignment:** `docs/VMR0015_v1.0_provision_alignment.md`.

Test data is a real Verra project (VCS 3599), 2025 H1, and the on-chain result matches the registry issuance.
