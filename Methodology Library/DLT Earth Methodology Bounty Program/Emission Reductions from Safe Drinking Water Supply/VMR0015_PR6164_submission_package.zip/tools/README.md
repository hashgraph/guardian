# Originality — VMR0015 v1.0 Safe Drinking Water dMRV

This policy was built independently for the DLT Earth Methodology Bounty. It implements the
**published AMS-III.AV. / VMR0015 equations** (which are public methodology, not proprietary code),
but the Guardian policy itself — its blocks, schemas, roles, calculation logic and lifecycle — is my
own work and is **not derived from, copied out of, or a re-skin of** the official CDM or Verra
reference policies shipped in the Guardian Methodology Library.

## What `verify_originality.py` checks

`verify_originality.py` is a static scan over the policy binary (`policy.json` inside the `.policy`
zip). It fails if it finds any artifact that would indicate the policy was lifted from an official
reference rather than authored fresh:

| Marker class | Examples | Why it's forbidden |
|---|---|---|
| CDM token / topic IDs | `0.0.3969810`, `0.0.3969809` | These belong to the official CDM reference deployment; their presence means copied on-chain artifacts. |
| Official IRI prefixes | `00ad3636`, `7c6e3bfe`, `a76cb53c`, `8f48da39` | Schema/credential IRIs from the official PP/VVB/PD/MR reference schemas. |
| Reserved block tags | `approve_PP`, `approve_VVB`, `TrustChain`, `Choose_Roles`, `project_Pipeline`, `Monitoring_Reports_sr` | Verbatim block tags from the reference policies. My policy uses its own tag names (`approve_pp_documents_btn`, `sr_monitoring_pipeline`, etc.). |
| Mainnet message IDs | pattern `170[6-7]\d{6}\.\d{9}` | Hedera **mainnet** consensus message IDs — a dMRV bounty submission must be testnet/dry-run, never carry mainnet artifacts. |

Exit codes: `0` clean · `1` forbidden marker present · `2` read error.

## How to run it

```bash
python3 tools/verify_originality.py policy/VMR0015_validated.policy
```

## Result on the submitted policy

```
Forbidden markers: 0/12 present
Mainnet messageId pattern: 0 hits

Result: PASS (clean)
```

The submitted policy passes the scan: it carries **no** CDM/Verra reference identifiers, **no**
official IRI prefixes, **no** reserved reference tags, and **no** mainnet message IDs.

## Originality declaration

I, the submitter (GitHub: BikramBiswas786), declare that:

1. The Guardian policy, its schemas, calculation block, role workflow and lifecycle were authored by
   me for this bounty.
2. The mathematics implements the **public** UNFCCC CDM AMS-III.AV. equations and Verra VMR0015 v1.0
   provisions; no proprietary or license-restricted material is reproduced.
3. The policy is not a copy or derivative of the official CDM/Verra reference policies in the Guardian
   Methodology Library; `verify_originality.py` (above) is the supporting automated check.
4. All on-chain artifacts in this submission are **Hedera testnet / Guardian dry-run** — no mainnet
   identifiers are present.
