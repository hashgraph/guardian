# Evidence Index — Canonical VCS 3599 Mint with REDD+ Attestation (Hedera testnet dry-run, 2026-06-15)

Policy instance `6a2fba4a426a359010481b55` · Monitoring Report schema `#b11a157f-296e-45dd-bc91-99c2f7a98566` (21 fields incl. REDD+)

| # | File | Type | Signer (role) | Time (UTC) | Key content |
|---|---|---|---|---|---|
| 01 | 01_PUBLISH_VC.json | Policy PUBLISH | SR (4dTuLj1j) | 08:39:56 | Policy&1.0.0, isMintNeeded=true |
| 02 | 02_MR_submit_PP.json | Monitoring Report | PP (Ang33m9o) | 08:45:10 | **ER blank on entry → field3=162241.14, field6=154125.14**; **field19=true** (REDD+ assessed), field20 justification |
| 03 | 03_MR_verify_VVB.json | Monitoring Report | VVB (8JG46Wpz) | 08:45:32 | values + REDD+ preserved |
| 04 | 04_MR_approve_SR.json | Monitoring Report | SR (4dTuLj1j) | 08:46:05 | values + REDD+ preserved |
| 05 | 05_MintToken_154125.json | MintToken VC | SR (4dTuLj1j) | 08:46:05 | **amount = 154125.14** |
| 06 | 06_VerifiablePresentation.json | VP | SR (4dTuLj1j) | 08:46:05 | bundles MR + MintToken (Trustchain anchor) |

All credentials are Ed25519-signed by the dry-run DIDs.

**What this proves:** the Emission Reductions value was computed on-chain by `calculate_report_fields`
from the monitored parameters (ER field submitted blank) and carried through to the mint; the minted
amount (154,125.14) equals the computed ER and matches the Verra VCS 3599 registry issuance. The
VMR0015 v1.0 REDD+ double-counting attestation (field19/field20) is captured on the signed Monitoring
Report and preserved through verification, approval, and into the Verifiable Presentation.

**Scope:** Guardian dry-run (virtual token id `604a0992-…`, a UUID — not a `0.0.x` HTS token), so these
transactions are off-ledger and will not appear on HashScan. They prove correct, methodology-driven,
REDD+-attested computation and minting; a production-mode run would anchor the same flow on-chain.
