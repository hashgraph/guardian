# Next Steps — Add REDD+ Field & Finalize Submission

You are currently running policy `…1781446804289` (real token `0.0.9234419`). It works:
canonical inputs compute BE 162,241.14 / ER 154,125.14 and mint 154,125. The only
remaining item is the VMR0015 v1.0 REDD+ double-counting field.

## Step 1 — Add the REDD+ fields (Guardian Excel import)

Use **`VMR0015_schemas_with_REDD.xlsx`** (in this `policy/` folder). It is your current
16-schema export with the Monitoring Report extended to 21 fields:
- `field19` — Boolean, Required — "REDD+ double-counting assessed (no overlap with REDD+/jurisdictional REDD+)"
- `field20` — String, Optional — "REDD+ double-counting justification / reference"

In Guardian:
1. Open your policy → **Schemas**.
2. Find **Monitoring Report** → import menu → **Import from Excel / from file**.
3. Select `VMR0015_schemas_with_REDD.xlsx`.
4. Save. Guardian rebuilds the schema (document + context + content files in sync).

## Step 2 — Verify the form

Open a new **Monitoring Report** form.
- ✅ If the two REDD+ fields appear → the import worked. Continue to Step 3.
- ❌ If the form still shows 19 fields or import errors → use the fallback:
  **Schemas → Monitoring Report → Edit → Add Field** twice:
  - Boolean, Required: "REDD+ double-counting assessed…"
  - Text, Optional: "REDD+ justification…"
  Save. (Same result, manual.)

## Step 3 — Re-run the canonical dry-run

Submit a Monitoring Report with:

| Field | Value |
|---|---|
| QPW_y (field12) | 713972729 |
| m (field13) | 0.95 |
| X_boil (field14) | 1 |
| nwb (field15) | 0.1 |
| EF_fuel (field16) | 81.6 |
| f_i (field17) | 0.82 |
| BL_fuel (field18) | 1 |
| PE (field4) | 0 |
| LE (field5) | 8116 |
| appliances pass/total (field10/field11) | 95 / 100 |
| **ER (field6)** | **leave BLANK** |
| **REDD+ assessed (field19)** | **true** |
| REDD+ justification (field20) | Point-of-use water purification; no REDD+ overlap |

PP submit → VVB verify → SR approve → mint.

Expected: field3 = **162,241.14**, field6 = **154,125.14**, mint = **154,125**.
(The REDD+ fields are inputs; they do not change the calculation.)

## Step 4 — Commit & update the PR

1. Replace `formulas/`, `tests/`, `docs/`, `evidence/`, `tools/`, `README.md`, `CHANGELOG.md`
   in your branch with the versions in this package (all consistent at IRI `e0013904`).
2. Export the new dry-run record (with REDD+ populated) → add to `evidence/`.
3. Paste `PR_BODY.md` as the PR description.
4. Screenshot the VCS 3599 registry issuance → add to `evidence/`.

## If you want to ship now (without REDD+)

Your current policy is a complete, working submission as-is (mints 154,125, real token).
Skip Steps 1–3, do Step 4, and add one line to the PR:
"REDD+ double-counting assessment is documented in docs/ (N/A for point-of-use water
purification); the attestation field is a planned schema addition."
